﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int radius = int.Parse(textBox1.Text);
            double a ;
            a = 2*radius*3.14;
            label2.Text = a.ToString();

            double c=radius*radius*3.14;
            label3.Text = c.ToString();




        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox2.Text);
            int b = int.Parse(textBox3.Text);
            int h=int.Parse(textBox4.Text);

            double c=2*(a+b);
            label6.Text = c.ToString();

            double d=a*h;
            label7.Text = d.ToString();
        }
    }
}
