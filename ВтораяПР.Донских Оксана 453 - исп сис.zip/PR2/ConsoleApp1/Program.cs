﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите радиус круга:");
            string input = Console.ReadLine();
            double radius = Convert.ToDouble(input);
            double a = 2 * radius * 3.14;
            double b = radius * radius * 3.14;
            Console.WriteLine("Radius "+a);
            Console.WriteLine("Plochad " + b);

            Console.WriteLine("Введите длину основания:");
            string inputt = Console.ReadLine();
            Console.WriteLine("Введите длину боковой стороны:");
            string inputt2 = Console.ReadLine();
            Console.WriteLine("Введите высоту:");
            string inputt3 = Console.ReadLine();

            double aa = Convert.ToDouble(inputt);
            double bb = Convert.ToDouble(inputt2);
            double h = Convert.ToDouble(inputt3);

            double pp = 2 * (aa + bb);
            double pl = aa * h;
            Console.WriteLine("Radius " + pp);
            Console.WriteLine("Plochad " + pl);



        }
    }
}
