﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace R5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {listBox1.Items.Clear();
            dataGridView1.RowCount = 3;
            dataGridView1.ColumnCount = 4;

            int[,] a = new int[3, 4];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 3; i++)
                for (j = 0; j < 4; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 3; i++)
                for (j = 0; j < 4; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);


            for (int row = 0; row < a.GetLength(0); row++)
            {
                int minValue = Int32.MaxValue; // Начинаем искать минимум с максимального значения

                for (int col = 0; col < a.GetLength(1); col++)
                {
                    if (a[row, col] < minValue)
                        
                        minValue = a[row, col]; // Обновляем минимум


                }
                
                listBox1.Items.Add(minValue);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                listBox1.Items.Clear();
                dataGridView1.RowCount = 3;
                dataGridView1.ColumnCount = 3;

                int[,] a = new int[3, 3];
                int i, j;

                Random rnd = new Random();
                for (i = 0; i < 3; i++)
                    for (j = 0; j < 3; j++)
                        a[i, j] = rnd.Next(-100, 100);

                for (i = 0; i < 3; i++)
                    for (j = 0; j < 3; j++)
                        dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int sum = 0;
            for ( j = 0; j < 3; j++)
            {
                sum += a[1, j]; 
            }
            listBox1.Items.Add("Сумма второй строки="+sum);
            int proiz = 1;
            for (j = 0; j < 3; j++)
            {
                proiz *= a[0, j]; // берем первую строку, индекс 0
            }
            listBox1.Items.Add("Произведение первой строки = " + proiz);



        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 4;

            int[,] a = new int[4, 4];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 4; i++)
                for (j = 0; j < 4; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 4; i++)
                for (j = 0; j < 4; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int diog = a[0, 0]; // Начнем с первого элемента главной диагонали
            for (int k = 1; k < 4; k++)
            {
                if (a[k, k] > diog)
                {
                    diog = a[k, k];
                }
            }
            listBox1.Items.Add("Наибольший элемент главной диогонали = " + diog);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 3;

            int[,] a = new int[4, 3];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int maxElement = a[0, 0]; // Берем начальное значение первым элементом матрицы
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    if (a[i, j] > maxElement)
                    {
                        maxElement = a[i, j];
                    }
                }
            }
            listBox1.Items.Add("Наибольший элемент матрицы = " + maxElement);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 3;

            int[,] a = new int[4, 3];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int positiveCount = 0;
            for ( i = 0; i < 4; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    if (a[i, j] > 0)
                    {
                        positiveCount++;
                    }
                }
            }
            listBox1.Items.Add("Количество положительных элементов= " + positiveCount);


        }
    }
}
