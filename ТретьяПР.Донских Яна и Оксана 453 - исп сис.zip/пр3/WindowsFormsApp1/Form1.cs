﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int primer = listBox1.SelectedIndex;
            string input = listBox1.Text.Trim();
            string result = "";
            switch (primer)
            {
                case 0:
                    result = btnCount_Click(input);
                    break;
                case 1:
                    result = CountWords(input);
                    break;
                case 2:
                    result = CountPunctuationMarks(input);
                    break;
                case 3:
                    result = ExtractDigits(input);
                    break;
                case 4:
                    result = CountEvenNumbers(input);
                    break;
                case 5:
                    result = RussianLowercaseCount(input);
                    break;
                case 6:
                    result = OutputRussianLowercase(input);
                    break;
                case 7:
                    result = CapitalizeFirstLetters(input);
                    break;
                case 8:
                    result = RemoveFirstLetters(input);
                    break;
                case 9:
                    result = SwapIJLetters(input);
                    break;
                case 10:
                    result = buttonSwapFirstLast_Click(input);///
                    break;
                case 11:
                    result = buttonReplaceLatin_Click(input);///
                    break;
                case 12:
                    result = bucvaA(input);//
                    break;
                case 13:
                    result = palid(input);
                    break;
                case 14:
                    result = danaStrokaChisla(input);
                    break;
            }
            label2.Text = result;

        }

        private string btnCount_Click(string input)
        {
            int zeros = input.Count(i => i == '0');
            int ones = input.Count(i => i == '1');

            return $"Нулей: {zeros}, Единиц: {ones}";
        }

        private string CountWords(string input)
        {
            string[] words = input.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            return $"Количество слов: {words.Length}";
        }

        private string CountPunctuationMarks(string input)
        {
            var punctuations = new HashSet<char>(".,;:'\"?!-");
            int count = input.Count(c => punctuations.Contains(c));
            return $"Знаков препинания: {count}";
        }

        private string ExtractDigits(string input)
        {
            return new string(input.Where(char.IsDigit).ToArray());
        }

        private string CountEvenNumbers(string input)
        {
            string[] parts = input.Split(' ');

            IEnumerable<int> numbers = parts
                                        .Where(part => part.All(char.IsDigit))      
                                        .Select(part => int.Parse(part));         

            
            int evenCount = numbers.Count(num => num % 2 == 0);

            
            return $"Четных чисел: {evenCount}";
        }

        private string RussianLowercaseCount(string input)
        {
            int lowercaseCount = input.Count(c => Char.IsLetter(c) && Char.IsLower(c) && c >= 'а' && c <= 'я');
            return $"Строчных русских букв: {lowercaseCount}";
        }

        private string OutputRussianLowercase(string input)
        {
            return new string(input.Where(c => Char.IsLetter(c) && Char.IsLower(c) && c >= 'а' && c <= 'я').ToArray());
        }

        private string CapitalizeFirstLetters(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return input;

            var words = input.Split(new char[] { ' ', '\t', '\n' }, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 0)
                {
                   
                    words[i] = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(words[i]);
                }
            }

            return string.Join(" ", words);
        }

        private string RemoveFirstLetters(string input)
        {
            string[] words = input.Split(' ');
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 1)
                    words[i] = words[i].Substring(1); 
            }
            return string.Join(" ", words);
        }

        private string SwapIJLetters(string input)
        {
           
            int i, j;
            if (!int.TryParse(textBox1.Text, out i))
            {
                label2.Text = "Ошибка: неправильное значение в первом индексе.";
                return "";
            }
            if (!int.TryParse(textBox2.Text, out j))
            {
                label2.Text = "Ошибка: неправильное значение во втором индексе.";
                return "";
            }

         
            char[] chars = input.ToCharArray();

            
            if (i >= 0 && i < input.Length && j >= 0 && j < input.Length)
            {
               
                char temp = chars[i];
                chars[i] = chars[j];
                chars[j] = temp;
            }
            else
            {
                label2.Text = "Ошибка: индексы вне диапазона.";
                return ""; 
            }

            
            return new string(chars);
        }

        private string buttonSwapFirstLast_Click(string input)
        {
            string[] words = input.Split(' '); 
            for (int i = 0; i < words.Length; i++)
            {
                if (words[i].Length > 1) 
                {
                    char first = words[i][0];               
                    char last = words[i][words[i].Length - 1]; 

                    
                    words[i] = last + words[i].Substring(1, words[i].Length - 2) + first;
                }
            }
            return string.Join(" ", words);

        }

        private string buttonReplaceLatin_Click(string input)
        {

            string modifiedString = new string(
            input.Select(c =>
             char.IsLetter(c) && ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
             ? '+'
             : c
             ).ToArray()
                );

            
            return string.Join(" ", modifiedString);
        }

        private string bucvaA(string input)
        {

            string modifiedString = input.Replace('А', '*');
            return string.Join(" ", modifiedString);
        }

        private string  palid(string input)
        {

            // string reversed = new string(input.Reverse().ToArray());
            // bool isPalindrome = input.Equals(reversed, StringComparison.OrdinalIgnoreCase);
            //string labelResult = isPalindrome ? "Это палиндром." : "Это НЕ палиндром.";
            // return string.Join(" ", labelResult);

            //string reversed = new string(input.Reverse().ToArray());
            //bool isPalindrome = input.Equals(reversed, StringComparison.OrdinalIgnoreCase);
            //return label2.Text = isPalindrome ? "палиндром" : "не палиндром";
            
            char[] inputarray = input.Replace(" ", "").ToUpper().ToCharArray();
            bool isPalindrome = inputarray.SequenceEqual(inputarray.Reverse()) ? true : false;
            return label2.Text = isPalindrome ? "палиндром" : "не палиндром";
        }

        private string danaStrokaChisla(string input)
        {

            string lengths = string.Join(" ", input.Split().Select(w => w.Length.ToString()));
            return label2.Text = lengths;
        }

    }
}
