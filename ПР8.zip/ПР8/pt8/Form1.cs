﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pt8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public double Funtic (double x)
        {

            double f = x + 1;
            return f;
        }


        private void button1_Click(object sender, EventArgs e)
        {
            double x =double.Parse(textBox1.Text);
            double y =double.Parse(textBox2.Text);
            double a;

            listBox1.Items.Add("Результаты работы программы:");
            listBox1.Items.Add("При Х = : " + x);
            listBox1.Items.Add("При Y = : " + y);
            listBox1.Items.Add("При f(x)=x+1");


            if (x * y > 0)
            {
                a=Math.Pow((Funtic(x)+y),2)-Math.Sqrt(Funtic(x)*y);
            }
            else if (x * y < 0)
            {
                a = Math.Pow((Funtic(x) + y), 2) + Math.Sqrt((Math.Abs(Funtic(x)*y)));
            }
            else
            {
                a = Math.Pow((Funtic(x) + y), 2) + 1;
            }
            
            listBox1.Items.Add("a = " + a);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double x = double.Parse(textBox4.Text);
            double y = double.Parse(textBox3.Text);
            double c;

            listBox2.Items.Add("Результаты работы программы:");
            listBox2.Items.Add("При Х = : " + x);
            listBox2.Items.Add("При Y = : " + y);
            listBox2.Items.Add("При f(x)=x+1");

            if (x - y == 0)
            {
                c = Math.Pow((Funtic(x)), 2) + Math.Pow(y, 2) + Math.Sin(y);
            }
            else if (x - y > 0)
            {
                c=Math.Pow((Funtic(x)-y),2)+Math.Cos(y);
            }
            else
            {
                c=Math.Pow((y - Funtic(x)), 2) + Math.Tan(y);
            }
            listBox2.Items.Add("c = " + c);
            listBox2.Items.Add("c = " + Math.Cos(y));
            listBox2.Items.Add("c = " + Math.Pow((Funtic(x) - y), 2));

        }
    }
}
