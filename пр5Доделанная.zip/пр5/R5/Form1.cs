﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace R5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {listBox1.Items.Clear();
            dataGridView1.RowCount = 3;
            dataGridView1.ColumnCount = 4;

            int[,] a = new int[3, 4];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 3; i++)
                for (j = 0; j < 4; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 3; i++)
                for (j = 0; j < 4; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);


            for (int row = 0; row < a.GetLength(0); row++)
            {
                int minValue = Int32.MaxValue; // Начинаем искать минимум с максимального значения

                for (int col = 0; col < a.GetLength(1); col++)
                {
                    if (a[row, col] < minValue)
                        
                        minValue = a[row, col]; // Обновляем минимум


                }
                
                listBox1.Items.Add(minValue);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
                listBox1.Items.Clear();
                dataGridView1.RowCount = 3;
                dataGridView1.ColumnCount = 3;

                int[,] a = new int[3, 3];
                int i, j;

                Random rnd = new Random();
                for (i = 0; i < 3; i++)
                    for (j = 0; j < 3; j++)
                        a[i, j] = rnd.Next(-100, 100);

                for (i = 0; i < 3; i++)
                    for (j = 0; j < 3; j++)
                        dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int sum = 0;
            for ( j = 0; j < 3; j++)
            {
                sum += a[1, j]; 
            }
            listBox1.Items.Add("Сумма второй строки="+sum);
            int proiz = 1;
            for (j = 0; j < 3; j++)
            {
                proiz *= a[0, j]; // берем первую строку, индекс 0
            }
            listBox1.Items.Add("Произведение первой строки = " + proiz);



        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 4;

            int[,] a = new int[4, 4];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 4; i++)
                for (j = 0; j < 4; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 4; i++)
                for (j = 0; j < 4; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int diog = a[0, 0]; // Начнем с первого элемента главной диагонали
            for (int k = 1; k < 4; k++)
            {
                if (a[k, k] > diog)
                {
                    diog = a[k, k];
                }
            }
            listBox1.Items.Add("Наибольший элемент главной диогонали = " + diog);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 3;

            int[,] a = new int[4, 3];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int maxElement = a[0, 0]; // Берем начальное значение первым элементом матрицы
            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    if (a[i, j] > maxElement)
                    {
                        maxElement = a[i, j];
                    }
                }
            }
            listBox1.Items.Add("Наибольший элемент матрицы = " + maxElement);

        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 3;

            int[,] a = new int[4, 3];
            int i, j;

            Random rnd = new Random();
            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    a[i, j] = rnd.Next(-100, 100);

            for (i = 0; i < 4; i++)
                for (j = 0; j < 3; j++)
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);

            int positiveCount = 0;
            for ( i = 0; i < 4; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    if (a[i, j] > 0)
                    {
                        positiveCount++;
                    }
                }
            }
            listBox1.Items.Add("Количество положительных элементов= " + positiveCount);


        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Очищаем listBox
            listBox1.Items.Clear();

            // Настройка сетки DataGridView
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 4;

            dataGridView2.RowCount = 4;
            dataGridView2.ColumnCount = 4;

            // Создание массива 4x4
            int[,] a = new int[4, 4];

            // Генерация случайных чисел
            Random rnd = new Random();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    a[i, j] = rnd.Next(-100, 100);  // Заполняем случайными значениями
                }
            }

            // Заполняем таблицу данными
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

            // Расчет суммы элементов главной диагонали
            int diagonalSum = 0;
            for (int k = 0; k < 4; k++)
            {
                diagonalSum += a[k, k];  // Главная диагональ - элементы вида a[i][i]
            }

            // Заменяем последний элемент на сумму главной диагонали
            a[3, 3] = diagonalSum;  // Для матрицы 4x4 последний элемент - a[3,3]

            // Обновляем таблицу с новым значением
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    dataGridView2.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            // Настройка сетки DataGridView
            dataGridView1.RowCount = 12;
            dataGridView1.ColumnCount = 12;

            dataGridView2.RowCount = 12;
            dataGridView2.ColumnCount = 12;

            int[,] a = new int[12, 12];

            // Генерация случайных чисел
            Random rnd = new Random();
            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 12; j++)
                {
                    a[i, j] = rnd.Next(-100, 100);  // Заполняем случайными значениями
                }
            }


            for (int i = 0; i < 12; i++)
            {
                for (int j = 0; j < 12; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

            int[] sums = new int[12]; // Массив для хранения сумм по столбцам
            for (int j = 0; j < 12; j++)
            {
                int sum = 0;
                for (int i = 0; i < 12; i++)
                {
                    sum += a[i, j]; // Суммируем элементы текущего столбца
                }
                sums[j] = sum;
            }



           // Выводим результаты суммирования во второй DataGridView
            for (int j = 0; j < 12; j++)
            {
                dataGridView2.Rows[j].Cells[0].Value = sums[j].ToString();
            }


        }

        private void button8_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            // Настройка сетки DataGridView
            dataGridView1.RowCount = 10;
            dataGridView1.ColumnCount = 10;

            dataGridView2.RowCount = 10;
            dataGridView2.ColumnCount = 10;

            int[,] a = new int[10, 10];

            // Генерация случайных чисел
            Random rnd = new Random();
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    a[i, j] = rnd.Next(-100, 100);  // Заполняем случайными значениями
                }
            }


            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

            int maxElement = int.MinValue;
            int maxRowIndex = -1;
            int maxColIndex = -1;

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (a[i, j] > maxElement)
                    {
                        maxElement = a[i, j];
                        maxRowIndex = i;
                        maxColIndex = j;
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                a[maxRowIndex, i] = 0; // Строка, где находился максимум
                a[i, maxColIndex] = 0; // Столбец, где находился максимум
            }

            // Записываем изменённую матрицу во вторую сетку
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    dataGridView2.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

        }

        private void button9_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            // Настройка сетки DataGridView
            dataGridView1.RowCount = 16;
            dataGridView1.ColumnCount = 16;

            dataGridView2.RowCount = 16;
            dataGridView2.ColumnCount = 16;

            int[,] a = new int[16, 16];

            // Генерация случайных чисел
            Random rnd = new Random();
            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    a[i, j] = rnd.Next(-100, 100);  // Заполняем случайными значениями
                }
            }


            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

            for (int i = 0; i < 16; i++)
            {
                int maxInRow = int.MinValue; // Минимально возможное целое число
                int maxColIndex = 0; // Координата столбца максимального элемента

                // Поиск наибольшего элемента в строке
                for (int j = 0; j < 16; j++)
                {
                    if (a[i, j] > maxInRow)
                    {
                        maxInRow = a[i, j];
                        maxColIndex = j;
                    }
                }

                // Помещаем наибольший элемент на главную диагональ
                a[i, i] = maxInRow;

                // Элемент, стоящий на месте нового положения, переносим обратно
                a[i, maxColIndex] = a[i, i]; // Чтобы избежать потери данных
            }

            // Заполняем DataGridView2 преобразованной матрицей
            for (int i = 0; i < 16; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    dataGridView2.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

        }

        private void button10_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            // Настройка сетки DataGridView
            dataGridView1.RowCount = 9;
            dataGridView1.ColumnCount = 9;

            dataGridView2.RowCount = 9;
            dataGridView2.ColumnCount = 9;

            int[,] a = new int[9, 9];

            // Генерация случайных чисел
            Random rnd = new Random();
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    a[i, j] = rnd.Next(-100, 100);  // Заполняем случайными значениями
                }
            }


            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    dataGridView1.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

            for (int i = 0; i < 9; i++)
            {
                int minInRow = int.MaxValue; // Начинаем с максимально возможного целого числа
                for (int j = 0; j < 9; j++)
                {
                    if (a[i, j] < minInRow)
                    {
                        minInRow = a[i, j]; // Обновляем минимальное значение
                    }
                }
                a[i, 0] = minInRow; // Ставим минимум на первое место строки
            }

            // Выводим преобразованную матрицу во вторую сетку
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    dataGridView2.Rows[i].Cells[j].Value = Convert.ToString(a[i, j]);
                }
            }

        }
    }
}
