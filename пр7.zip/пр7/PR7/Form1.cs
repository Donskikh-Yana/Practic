﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PR7
{
    public partial class Form1 : Form
    {
        private Random random = new Random();
        private Bitmap bitmap;
        private Graphics graphics;
        private Pen pen = new Pen(Color.Black);
        private bool isDrawing = false;
        private Point lastPoint;

        private Bitmap originalBitmap;
        private Bitmap grayscaleBitmap;
        private Bitmap filteredBitmap;
        private Bitmap modifiedBitmap;

        public Form1()
        {
            InitializeComponent();

            bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            graphics = Graphics.FromImage(bitmap);
            pictureBox1.Image = bitmap;


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            pen.Width = trackBar1.Value;
        }

        private void buttonChangeColor_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                
                pen.Color = colorDialog1.Color;
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isDrawing = true;
            lastPoint = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
              
                graphics.DrawLine(pen, lastPoint, e.Location);
                lastPoint = e.Location;
                pictureBox1.Invalidate(); 
            }
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDrawing = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.BMP, *.JPG, *.PNG)|*.bmp;*.jpg;*.png";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    originalBitmap = new Bitmap(dialog.FileName);
                    pictureBox1.Image = originalBitmap;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке изображения:\n{ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "PNG Files (*.png)|*.png";

            if (saveDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    
                    bitmap.Save(saveDialog.FileName, ImageFormat.Png);
                }
                catch
                {
                    MessageBox.Show("Ошибка сохранения файла.");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
               
                pen.Color = colorDialog1.Color;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 1000; i++)
            {
                int x = random.Next(0, pictureBox1.Width);      
                int y = random.Next(0, pictureBox1.Height);     

                // Генерируем случайный цвет
                int r = random.Next(0, 256);                     // Красный
                int g = random.Next(0, 256);                     // Зеленый
                int b = random.Next(0, 256);                     // Синий
                Color dotColor = Color.FromArgb(r, g, b);

                // Рисуем точку заданного цвета
                SolidBrush brush = new SolidBrush(dotColor);
                graphics.FillEllipse(brush, x, y, 5, 5);       // Точка размером 1х1 пиксель
            }

           
            pictureBox1.Refresh();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            grayscaleBitmap = new Bitmap(bitmap.Width, bitmap.Height);

            for (int x = 0; x < bitmap.Width; x++)
            {
                for (int y = 0; y < bitmap.Height; y++)
                {
                    
                    Color pixelColor = bitmap.GetPixel(x, y);

                    byte grayValue = (byte)(pixelColor.R * 0.299f + pixelColor.G * 0.587f + pixelColor.B * 0.114f);

                    grayscaleBitmap.SetPixel(x, y, Color.FromArgb(grayValue, grayValue, grayValue));
                }
            }

            pictureBox1.Image = grayscaleBitmap;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            filteredBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);

            for (int x = 0; x < originalBitmap.Width; x++)
            {
                for (int y = 0; y < originalBitmap.Height; y++)
                {
                    Color pixelColor = originalBitmap.GetPixel(x, y);

                    switch (comboBox1.SelectedItem)
                    {
                        case "R": // Оставляем красный канал
                            filteredBitmap.SetPixel(x, y, Color.FromArgb(pixelColor.R, 0, 0));
                            break;

                        case "G": // Оставляем зелёный канал
                            filteredBitmap.SetPixel(x, y, Color.FromArgb(0, pixelColor.G, 0));
                            break;

                        case "B": // Оставляем синий канал
                            filteredBitmap.SetPixel(x, y, Color.FromArgb(0, 0, pixelColor.B));
                            break;
                    }
                }
            }
            pictureBox1.Image = filteredBitmap;



        }

        private void button7_Click(object sender, EventArgs e)
        {
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);
            int radius=int.Parse(textBox1.Text.ToString());
            // Находим центр изображения
            int centerX = pictureBox1.Width / 2;
            int centerY = pictureBox1.Height / 2;

            for (int x = 0; x < originalBitmap.Width; x++)
            {
                for (int y = 0; y < originalBitmap.Height; y++)
                {
                    double distance = Math.Sqrt((centerX - x) * (centerX - x) + (centerY - y) * (centerY - y));

                    // Если пиксель вне круга — делаем его чёрным
                    if (distance > radius)
                    {
                        modifiedBitmap.SetPixel(x, y, Color.Black);
                    }
                    else
                    {
                        // Иначе оставляем пиксель оригинальным
                        modifiedBitmap.SetPixel(x, y, originalBitmap.GetPixel(x, y));
                    }
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }
        private Point[] vertices = new Point[]
   {
        new Point(100, 100),
        new Point(300, 100),
        new Point(200, 300)
   };

        private bool IsInsideTriangle(Point p, Point a, Point b, Point c)
        {
            double sign(double x1, double y1, double x2, double y2, double x3, double y3)
            {
                return (x1 - x3) * (y2 - y3) - (x2 - x3) * (y1 - y3);
            }

            bool d1 = sign(p.X, p.Y, a.X, a.Y, b.X, b.Y) >= 0;
            bool d2 = sign(p.X, p.Y, b.X, b.Y, c.X, c.Y) >= 0;
            bool d3 = sign(p.X, p.Y, c.X, c.Y, a.X, a.Y) >= 0;

            return (d1 && d2 && d3) || (!(d1 || d2 || d3));
        }
        private void button8_Click(object sender, EventArgs e)
        {
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);

          
            Point a = vertices[0];
            Point b = vertices[1];
            Point c = vertices[2];

            for (int x = 0; x < originalBitmap.Width; x++)
            {
                for (int y = 0; y < originalBitmap.Height; y++)
                {
                    if (!IsInsideTriangle(new Point(x, y), a, b, c))
                    {
                        modifiedBitmap.SetPixel(x, y, Color.Blue);
                    }
                    else
                    {
                        modifiedBitmap.SetPixel(x, y, originalBitmap.GetPixel(x, y));
                    }
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }
        private Point[] rhombusVertices =
{
    new Point(200, 100), // Верхняя точка
    new Point(100, 200), // Левая точка
    new Point(200, 300), // Нижняя точка
    new Point(300, 200)  // Правая точка
};

        private bool IsInRhombus(Point point, Point[] vertices)
        {
            for (int i = 0; i < vertices.Length; i++)
            {
                Point currentVertex = vertices[i];
                Point nextVertex = vertices[(i + 1) % vertices.Length]; 

                int sideSign = Sign(currentVertex.X, currentVertex.Y, nextVertex.X, nextVertex.Y, point.X, point.Y);

                if (sideSign <= 0)
                {
                    return false; 
                }
            }

            return true; 
        }
        private static int Sign(int x1, int y1, int x2, int y2, int px, int py)
        {
            return (px - x1) * (y2 - y1) - (py - y1) * (x2 - x1);
        }
        private void button9_Click(object sender, EventArgs e)
        {
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);

            for (int x = 0; x < originalBitmap.Width; x++)
            {
                for (int y = 0; y < originalBitmap.Height; y++)
                {
                    Point currentPoint = new Point(x, y);

                    if (IsInRhombus(currentPoint, rhombusVertices))
                    {
                        modifiedBitmap.SetPixel(x, y, Color.Green);
                    }
                    else
                    {
                        Color pixelColor = originalBitmap.GetPixel(x, y);
                        int grayLevel = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                        modifiedBitmap.SetPixel(x, y, Color.FromArgb(grayLevel, grayLevel, grayLevel));
                    }
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);
            using (Graphics g = Graphics.FromImage(modifiedBitmap))
            {
                g.DrawImage(originalBitmap, 0, 0);

                Pen thinBlackPen = new Pen(Color.Black, 1); 

                for (int y = 0; y < originalBitmap.Height; y += 2)
                {
                    g.DrawLine(thinBlackPen, 0, y, originalBitmap.Width, y);
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);
            using (Graphics g = Graphics.FromImage(modifiedBitmap))
            {
                g.DrawImage(originalBitmap, 0, 0);

                Pen thinBlackPen = new Pen(Color.Black, 1); 

                for (int x = 1; x < originalBitmap.Width; x += 2)
                {
                    
                    g.DrawLine(thinBlackPen, x, 0, x, originalBitmap.Height);
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            int halfWidth = pictureBox1.Width / 2;
            int halfHeight = pictureBox1.Height / 2;

            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);

            for (int x = 0; x < originalBitmap.Width; x++)
            {
                for (int y = 0; y < originalBitmap.Height; y++)
                {
                    Color originalColor = originalBitmap.GetPixel(x, y);

                    if (x < halfWidth && y < halfHeight)
                    {
                        modifiedBitmap.SetPixel(x, y, Color.FromArgb(originalColor.R, 0, 0));
                    }
                    else if (x >= halfWidth && y < halfHeight)
                    {
                        modifiedBitmap.SetPixel(x, y, Color.FromArgb(0, originalColor.G, 0));
                    }
                    else if (x < halfWidth && y >= halfHeight)
                    {
                        modifiedBitmap.SetPixel(x, y, Color.FromArgb(0, 0, originalColor.B));
                    }
                    else
                    {
                        int grayLevel = (originalColor.R + originalColor.G + originalColor.B) / 3;
                        modifiedBitmap.SetPixel(x, y, Color.FromArgb(grayLevel, grayLevel, grayLevel));
                    }
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }

       

        private void button13_Click(object sender, EventArgs e)
        {
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);

            for (int x = 0; x < originalBitmap.Width; x++)
            {
                for (int y = 0; y < originalBitmap.Height; y++)
                {
                    Color pixelColor = originalBitmap.GetPixel(x, y);

                    int grayLevel = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;

                    int invertedGrayLevel = 255 - grayLevel;

                    modifiedBitmap.SetPixel(x, y, Color.FromArgb(invertedGrayLevel, invertedGrayLevel, invertedGrayLevel));
                }
            }

            
            pictureBox1.Image = modifiedBitmap;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            int cellSize = int.Parse(textBox2.Text.ToString()); 
            modifiedBitmap = new Bitmap(originalBitmap.Width, originalBitmap.Height);

            for (int x = 0; x < originalBitmap.Width; x += cellSize)
            {
                for (int y = 0; y < originalBitmap.Height; y += cellSize)
                {
                    int centerX = x + cellSize / 2;
                    int centerY = y + cellSize / 2;

                    if (centerX >= originalBitmap.Width) centerX = originalBitmap.Width - 1;
                    if (centerY >= originalBitmap.Height) centerY = originalBitmap.Height - 1;

                    Color avgColor = originalBitmap.GetPixel(centerX, centerY);

                    for (int dx = 0; dx < cellSize && x + dx < originalBitmap.Width; dx++)
                    {
                        for (int dy = 0; dy < cellSize && y + dy < originalBitmap.Height; dy++)
                        {
                            modifiedBitmap.SetPixel(x + dx, y + dy, avgColor);
                        }
                    }
                }
            }

            pictureBox1.Image = modifiedBitmap;
        }
    }
}
    

