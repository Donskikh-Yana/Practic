﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form4 : Form
    {
        List<object[]> planets = new List<object[]>()
    {
        new object[] {"Меркурий", 100, 10, Color.Gray, 0},
        new object[] {"Венера", 150, 15, Color.LightYellow, 0},
        new object[] {"Земля", 200, 20, Color.Green, 0},
        new object[] {"Марс", 250, 15, Color.Red, 0},
        new object[] {"Юпитер", 300, 30, Color.Pink, 0},
        new object[] {"Сатурн", 350, 25, Color.LightGray, 0},
        new object[] {"Уран", 400, 20, Color.Cyan, 0},
        new object[] {"Нептун", 450, 15, Color.DeepSkyBlue, 0}
    };

        public Form4()
        {
            
            InitializeComponent();
            DoubleBuffered = true; // Устраняем мерцание
            timer1.Interval = 55; // Интервал обновления в миллисекундах
            timer1.Tick += Timer1_Tick; // Обработчик события таймера
            timer1.Start(); // Запускаем таймер
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < planets.Count; i++)
            {
                // Выполняем расчет нового угла
                double currentAngle = Convert.ToDouble(planets[i][4]);
                double angularSpeed = Math.PI / (Convert.ToInt32(i) + 2); // Скорость определяется порядковым номером планеты
                double newAngle = currentAngle + angularSpeed * timer1.Interval / 1000.0;

                // Сохраняем новый угол
                planets[i][4] = newAngle;
            }

            Invalidate(); // Перерисовываем форму
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.Black); // Темный фон

            // Рисуем солнце
            g.FillEllipse(new SolidBrush(Color.Yellow), Width / 2 - 50, Height / 2 - 50, 100, 100);

            // Проходим по списку планет и рисуем каждую
            foreach (object[] planetInfo in planets)
            {
                string name = (string)planetInfo[0];
                int orbitRadius = Convert.ToInt32(planetInfo[1]);
                int diameter = Convert.ToInt32(planetInfo[2]);
                Color color = (Color)planetInfo[3];
                double angle = Convert.ToDouble(planetInfo[4]); // Текущий угол

                // Рассчитываем текущую позицию планеты на орбите
                double angleRadians = angle;
                int x = (int)(Width / 2 + Math.Cos(angleRadians) * orbitRadius);
                int y = (int)(Height / 2 + Math.Sin(angleRadians) * orbitRadius);

                // Рисуем планету
                g.FillEllipse(new SolidBrush(color), x - diameter / 2, y - diameter / 2, diameter, diameter);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.ShowDialog();
        }
    }
}
