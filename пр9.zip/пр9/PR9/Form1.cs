﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form1 : Form
    {
        private Pen pen = new Pen(Color.Red, 3); // Конкретный цвет контура
        private SolidBrush brush = new SolidBrush(Color.Red); // Цвет заливки
        private float scaleFactor = 1.0f; // Начальный масштаб сердца
        private bool grow = true; // Растёт или уменьшается сердце
        private float increment = 0.03f; // Скорость изменения размера


        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true; // Предотвращение мерцания при перерисовке
            timer1.Interval = 50; // Частота обновления (50 мс)
            timer1.Tick += timer1_Tick; // Обработчик события таймера
            timer1.Start(); // Запускаем таймер
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (grow && scaleFactor >= 1.2f)
            {
                grow = false; // Начинаем уменьшить сердце
            }
            else if (!grow && scaleFactor <= 1.0f)
            {
                grow = true; // Начинаем увеличивать сердце
            }

            // Меняем масштаб сердца
            scaleFactor += increment * (grow ? 1 : -1);

            // Перерисовываем форму
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias; // Повышаем качество прорисовки

            // Получаем доступ к графике и применяем преобразования
            Graphics g = e.Graphics;
            g.ScaleTransform(scaleFactor, scaleFactor); // Масштабируем рисунок

            // Рисуем два пересекающихся круга
            Rectangle ellipseRect1 = new Rectangle(300, 100, 100, 100);
            Rectangle ellipseRect2 = new Rectangle(375, 100, 100, 100);

            // Рисуем первые два круга
            g.FillEllipse(brush, ellipseRect1);
            g.FillEllipse(brush, ellipseRect2);

            // Опорные точки для треугольника, завершающего сердце
            Point[] heartPoints = new Point[]
            {
            new Point(306, 175),
            new Point(469, 175),
            new Point(388, 255)
            };

            // Закрашиваем конечный полигон
            g.FillPolygon(brush, heartPoints);
        }
        public void Form1_Paint(object sender, PaintEventArgs e)
        {
           
            //Graphics g =e.Graphics;
            //float centerX = Width / 2f;
            //float centerY = Height / 2f;
            //g.DrawEllipse(pen, centerX - heartSize / 2, centerY - heartSize / 2, heartSize, heartSize);
            //pen.Dispose();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.ShowDialog();


        }
    }
}
