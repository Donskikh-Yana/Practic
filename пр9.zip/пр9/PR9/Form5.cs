﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form5 : Form
    {
        List<Tuple<string, int, int, Color>> planets = new List<Tuple<string, int, int, Color>>()
    {
        Tuple.Create("Меркурий", 100, 10, Color.DimGray),
        Tuple.Create("Венера", 150, 15, Color.LightGoldenrodYellow),
        Tuple.Create("Земля", 200, 20, Color.MediumSeaGreen),
        Tuple.Create("Марс", 250, 15, Color.Firebrick),
        Tuple.Create("Юпитер", 300, 30, Color.Tan),
        Tuple.Create("Сатурн", 350, 25, Color.Linen),
        Tuple.Create("Уран", 400, 20, Color.LightCyan),
        Tuple.Create("Нептун", 450, 15, Color.RoyalBlue)
    };

        // Константа — радиус земли
        readonly int earthRadius = 30;

        // Минимальное расстояние планет до Земли
        readonly int minDistance = 200;

        // Временная метрика для равномерного движения планет
        int tickCount = 0;
        public Form5()
        {
            InitializeComponent();
            DoubleBuffered = true; // Устраняем мерцание
            timer1.Interval = 50; // Интервал обновления в миллисекундах
            timer1.Tick += Timer1_Tick; // Обработчик события таймера
            timer1.Start(); // Запускаем таймер
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            tickCount++;

            // Обновляем расстояния планет с помощью цикла FOR
            for (int i = 0; i < planets.Count; i++)
            {
                // Доступ к данным планеты
                var planet = planets[i]; // Копия планеты
                int radius = planet.Item2; // Исходный радиус орбиты
                int distanceToEarth = radius - (tickCount * 5); // Новое расстояние до Земли

                // Ограничиваем минимальное расстояние
                if (distanceToEarth < minDistance)
                {
                    distanceToEarth = minDistance;
                }

                // Возвращаем планеты обратно после прохождения минимального расстояния
                if (tickCount > 100) // Примерно после первой волны сближения
                {
                    distanceToEarth = radius + (tickCount - 100) * 5;
                }

                // Обновляем орбиту планеты в списке
                planets[i] = Tuple.Create(
                    planet.Item1, // Имя планеты
                    distanceToEarth, // Новый радиус орбиты
                    planet.Item3, // Диаметр
                    planet.Item4 // Цвет
                );
            }

            Invalidate(); // Перерисовываем форму
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.Black); // Темный фон

            // Рисуем землю
            g.FillEllipse(new SolidBrush(Color.Gold), Width / 2 - earthRadius, Height / 2 - earthRadius, earthRadius * 2, earthRadius * 2);

            // Проходим по списку планет и рисуем каждую
            foreach (Tuple<string, int, int, Color> planet in planets)
            {
                int orbitRadius = planet.Item2; // Радиус орбиты
                int diameter = planet.Item3; // Диаметр планеты
                Color color = planet.Item4; // Цвет планеты

                // Рассчитываем позицию планеты на орбите
                int x = Width / 2 + orbitRadius;
                int y = Height / 2;

                // Рисуем планету
                g.FillEllipse(new SolidBrush(color), x - diameter / 2, y - diameter / 2, diameter, diameter);
            }
        }
        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 form = new Form6();
            form.ShowDialog();
        }
    }
}
