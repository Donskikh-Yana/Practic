﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form3 : Form
    {
        private int xPos = 50; // Начальная позиция человечка по оси X
        private int yPos = 150; // Высота расположения человечка
        private int frameIndex = 0; // Индекс кадра анимации
        private bool movingRight = true; // Направление движения
        public Form3()
        {
            InitializeComponent();
            DoubleBuffered = true; // Убираем мерцание
            timer1.Interval = 100; // Интервал обновления (1 кадр каждые 100 ms)
            timer1.Tick += Timer1_Tick; // Обработчик события таймера
            timer1.Start(); // Запускаем таймер
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            // Продвижение человечка вперед
            if (movingRight)
            {
                xPos++;
                if (xPos > ClientSize.Width - 100) // Ограничение перемещения вправо
                {
                    movingRight = false;
                }
            }
            else
            {
                xPos--;
                if (xPos < 0) // Ограничение перемещения влево
                {
                    movingRight = true;
                }
            }

            // Циклическое изменение позы человечка
            frameIndex = (frameIndex + 1) % 4; // 4 фазы цикла ходьбы

            Invalidate(); // Перерисовка формы
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.LightBlue); // Фон голубого цвета

            // Голова
            g.FillEllipse(Brushes.Brown, xPos + 20, yPos - 30, 20, 20);

            // Туловище
            g.FillRectangle(Brushes.Blue, xPos, yPos, 40, 50);

            // Руки
            switch (frameIndex)
            {
                case 0:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 10, xPos - 20, yPos + 20); // Левая рука вверх
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 10, xPos + 60, yPos + 20); // Правая рука вниз
                    break;
                case 1:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 10, xPos - 20, yPos + 30); // Левая рука средняя
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 10, xPos + 60, yPos + 30); // Правая рука средняя
                    break;
                case 2:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 10, xPos - 20, yPos + 40); // Левая рука вниз
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 10, xPos + 60, yPos + 40); // Правая рука вверх
                    break;
                default:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 10, xPos - 20, yPos + 30); // Левая рука средняя
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 10, xPos + 60, yPos + 30); // Правая рука средняя
                    break;
            }

            // Ноги
            switch (frameIndex)
            {
                case 0:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 50, xPos + 10, yPos + 80); // Левая нога прямая
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 50, xPos + 30, yPos + 70); // Правая нога согнута
                    break;
                case 1:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 50, xPos + 10, yPos + 70); // Левая нога полусогнута
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 50, xPos + 30, yPos + 80); // Правая нога прямая
                    break;
                case 2:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 50, xPos + 10, yPos + 70); // Левая нога полусогнута
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 50, xPos + 30, yPos + 80); // Правая нога прямая
                    break;
                default:
                    g.DrawLine(Pens.Black, xPos + 10, yPos + 50, xPos + 10, yPos + 80); // Левая нога прямая
                    g.DrawLine(Pens.Black, xPos + 30, yPos + 50, xPos + 30, yPos + 70); // Правая нога согнута
                    break;
            }
        }
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 form = new Form4();
            form.ShowDialog();
        }
    }
}
