﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR9
{
    public partial class Form2 : Form
    {
        private List<Point> snowflakes = new List<Point>(); // Список снежинок
        private Random rand = new Random(); // Генератор случайных чисел


        public Form2()
        {
            InitializeComponent();
            DoubleBuffered = true; // Устраняет мерцание
            timer1.Interval = 50; // Интервал обновления в миллисекундах
            timer1.Tick += Timer1_Tick; // Обработчик события таймера
            timer1.Start(); // Запускаем таймер
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            // Передвигаем существующие снежинки вниз
            for (int i = 0; i < snowflakes.Count; i++)
            {
                snowflakes[i] = new Point(snowflakes[i].X, snowflakes[i].Y + 1); // Опускаем на единицу вниз
            }

            // Удаляем снежинки, вышедшие за пределы экрана
            snowflakes.RemoveAll(flake => flake.Y > ClientSize.Height);

            // Периодически добавляем новые снежинки
            if (rand.NextDouble() < 0.1) // Приблизительно 10% шанс добавления новой снежинки
            {
                int xPosition = rand.Next(0, ClientSize.Width); // Горизонтальная позиция
                snowflakes.Add(new Point(xPosition, -10)); // Новая снежинка появляется в верхней части окна
            }

            Invalidate(); // Запрашиваем перерисовку формы
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.Clear(Color.Black); // Черный фон

            // Рисуем каждую снежинку в виде белого кружочка
            foreach (var flake in snowflakes)
            {
                g.FillEllipse(new SolidBrush(Color.White), flake.X, flake.Y, 5, 5); // Маленькие белые кружочки
            }
        }
        private void Form2_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form= new Form3();
            form.ShowDialog();
        }
    }
}
