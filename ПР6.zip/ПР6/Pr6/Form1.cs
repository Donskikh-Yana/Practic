﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //Graphics g = e.Graphics;

            //g.Clear(Color.White);
            //for (int i = 0;i<50;i++)
            //{
            //    g.DrawLine(new Pen(Brushes.Black, 2), 10, 4 * i + 20, 200, 4 * i + 20);
            //}

            var g = e.Graphics;

            
          

            
            using (var brownBrush = new SolidBrush(Color.DarkBlue))
            {
                g.FillRectangle(brownBrush, 190, 250, 300, 150); //прямоугольник
            }

            using (var brownBrush = new SolidBrush(Color.Lavender))
            {
                g.FillRectangle(brownBrush, 290, 300, 55, 55); //прямоугольник
            }

            using (var brownBrush = new SolidBrush(Color.PeachPuff))
            {
                g.FillRectangle(brownBrush, 390, 300, 55, 110); //прямоугольник
            }

            using (var greenBrush = new SolidBrush(Color.DarkMagenta))
            {
                Point[] trianglePoints = { new Point(190, 250), new Point(490, 250), new Point(340, 140) };
                // Залить треугольник выбранным цветом
                e.Graphics.FillPolygon(greenBrush, trianglePoints);
            }


            using (var greenBrush = new SolidBrush(Color.Green))
            {
                g.FillRectangle(greenBrush, 0, 400, 900, 50); //прямоугольник закрашенный
            }

           
            //using (var grayPen = new Pen(Color.Gray, 2))
            //{
            //    g.DrawEllipse(grayPen, 250, 100, 100, 50); //овал
            //}





            
            using (var yellowBrush = new SolidBrush(Color.Yellow))
            {
                g.FillEllipse(yellowBrush, 730, -50, 150, 150); //солнце
            }

            using (var penBlueDashed = new Pen(Color.Yellow, 5))
            {
                
                g.DrawLine(penBlueDashed, 800, 50, 690, 100); //линия
            }

            using (var penBlueDashed = new Pen(Color.Yellow, 5))
            {

                g.DrawLine(penBlueDashed, 750, 20, 650, 20); //линия
            }

            using (var penBlueDashed = new Pen(Color.Yellow, 5))
            {

                g.DrawLine(penBlueDashed, 820, 40, 750, 150); //линия
            }



            // Многоугольник фиолетового цвета
            //Point[] polygonPoints =
            //{
            //    new Point(50, 250),
            //    new Point(100, 300),
            //    new Point(150, 250),
            //    new Point(100, 200)
            //};
            //using (var purplePen = new Pen(Color.Black, 2))
            //{
            //    g.DrawPolygon(purplePen, polygonPoints); // Нарисовать контур многоугольника
            //}

            //using (var pinkBrush = new SolidBrush(Color.Black))
            //{
            //    g.FillPolygon(pinkBrush, polygonPoints); // Зафиксируем внутренний цвет
            //}
        }
    
    }
}

