﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pr6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {

            //base.OnPaint(e);
            var g = e.Graphics;
           




            using (var brownBrush = new SolidBrush(Color.DarkBlue))
            {
                g.FillRectangle(brownBrush, 190, 250, 300, 150); //прямоугольник
            }

            using (var brownBrush = new SolidBrush(Color.Lavender))
            {
                g.FillRectangle(brownBrush, 290, 300, 55, 55); //прямоугольник
            }

            using (var brownBrush = new SolidBrush(Color.PeachPuff))
            {
                g.FillRectangle(brownBrush, 390, 300, 55, 110); //прямоугольник
            }

            using (var greenBrush = new SolidBrush(Color.DarkMagenta))
            {
                Point[] trianglePoints = { new Point(190, 250), new Point(490, 250), new Point(340, 140) };
                // Залить треугольник выбранным цветом
                e.Graphics.FillPolygon(greenBrush, trianglePoints);
            }


            using (var greenBrush = new SolidBrush(Color.Green))
            {
                g.FillRectangle(greenBrush, 0, 400, 900, 50); //прямоугольник закрашенный
            }






            using (var penBlueDashed = new Pen(Color.ForestGreen, 4))
            {

                g.DrawLine(penBlueDashed, 600, 400, 600, 250); //линия
            }

            using (var yellowBrush = new SolidBrush(Color.OrangeRed))
            {
                g.FillEllipse(yellowBrush, 572, 250, 55, 55); //солнце
            }

            using (var yellowBrush = new SolidBrush(Color.OrangeRed))
            {
                g.FillEllipse(yellowBrush, 572, 197, 55, 55); //солнце
            }

            using (var yellowBrush = new SolidBrush(Color.DarkOrange))
            {
                g.FillEllipse(yellowBrush, 589, 215, 20, 20); //солнце
            }

            using (var yellowBrush = new SolidBrush(Color.DarkOrange))
            {
                g.FillEllipse(yellowBrush, 589, 267, 20, 20); //солнце
            }

            using (var list = new SolidBrush(Color.ForestGreen))
            {

                float angle = -45f;          // Наклон влево
                Matrix oldMatrix = g.Transform.Clone();  // Сохраняем старое состояние

                PointF centerPoint = new PointF(565 + 25 / 2, 300 + 58 / 2);
                g.TranslateTransform(centerPoint.X, centerPoint.Y);
                g.RotateTransform(angle);
                g.FillEllipse(list, -(25 / 2), -(58 / 2), 25, 58);
                g.Transform = oldMatrix;     // Восстанавливаем оригинал
            }
            using (var list = new SolidBrush(Color.ForestGreen))
            {

                float angle = 45f;          // Наклон влево
                Matrix oldMatrix = g.Transform.Clone();  // Сохраняем старое состояние

                PointF centerPoint = new PointF(635 - 25 / 2, 358 - 58 / 2);
                g.TranslateTransform(centerPoint.X, centerPoint.Y);
                g.RotateTransform(angle);
                g.FillEllipse(list, -(25 / 2), -(58 / 2), 25, 58);
                g.Transform = oldMatrix;     // Восстанавливаем оригинал
            }


            using (var yellowBruh = new SolidBrush(Color.Yellow))
            {
                g.FillEllipse(yellowBruh, 730, -50, 150, 150); //солнце
            }

            using (var penBlueDashed = new Pen(Color.Yellow, 5))
            {
                
                g.DrawLine(penBlueDashed, 800, 50, 690, 100); //линия
            }

            using (var penBlueDashed = new Pen(Color.Yellow, 5))
            {

                g.DrawLine(penBlueDashed, 750, 20, 650, 20); //линия
            }

            using (var penBlueDashed = new Pen(Color.Yellow, 5))
            {

                g.DrawLine(penBlueDashed, 820, 40, 750, 150); //линия
            }


        }
    
    }
}

