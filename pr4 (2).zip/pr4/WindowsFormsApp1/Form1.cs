﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            var random = new Random();

            int[] array = Enumerable.Range(1, 20)
                                    .Select(_ => random.Next(-100, 100))
                                    .ToArray();

            OutputArray(listBox1, array, "Исходный массив:");

            int maxIndex = IndexOfMax(array);
            Swap(array, 0, maxIndex);
            OutputArray(listBox1, array, "\nМассив после замены первого элемента с максимальным значением:");
        }

       
        private int IndexOfMax(int[] array)
        {
            int maxIndex = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > array[maxIndex])
                    maxIndex = i;
            }
            return maxIndex;
        }
        private int IndexOfMax1(double[] array)
        {
            int maxIndex = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > array[maxIndex])
                    maxIndex = i;
            }
            return maxIndex;
        }

        private int IndexOfMin(int[] array)
        {
            int maxIndex = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < array[maxIndex])
                    maxIndex = i;
            }
            return maxIndex;
        }

       
        private int IndexOfMin1(double[] array)
        {
            int maxIndex = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < array[maxIndex])
                    maxIndex = i;
            }
            return maxIndex;
        }


        
        private void Swap<T>(T[] array, int index1, int index2)
        {
            T temp = array[index1];
            array[index1] = array[index2];
            array[index2] = temp;
        }

        private int nechetOtr(int [] array)
        {
            int summ = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i]<0 && array[i] % 2 != 0)
                {
                    summ += array[i];
                }
            }
            return summ;
        }

        private int crat5(int[] array)
        {
            int summ = 0;
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] % 5 == 0)
                {
                    summ += array[i];
                }
            }
            return summ;
        }
       

        
        private void OutputArray<T>(ListBox listBox, IEnumerable<T> array, string header)
        {
            listBox.Items.Add(header);
            //foreach (T item in array)
            //{
            //    listBox.Items.Add(item); // Каждый элемент отдельно ОКСАНЕ НАДО
            //}
            listBox.Items.Add(string.Join(", ", array));
        }
      


        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            var random = new Random();

            int[] array = Enumerable.Range(1, 10)
                                    .Select(_ => random.Next(-100, 100))
                                    .ToArray();
            OutputArray(listBox1, array, "Исходный массив:");
            int minIndex = IndexOfMin(array);
            Swap(array, 9, minIndex);
            OutputArray(listBox1, array, "\nМассив после замены последнего элемента с наименьшим значением:");


        }

        private void button3_Click(object sender, EventArgs e)
        {

            listBox1.Items.Clear();
            var random = new Random();
            double[] array = new double[15];


            for (int i = 0; i < 15; i++)
            {
                
                bool isInteger = random.Next(2) == 0;

                if (isInteger)
                    array[i] += random.Next(-100, 101);

                else
                    array[i] += ((random.NextDouble() * 200) - 100); 
            }
            OutputArray(listBox1, array, "Исходный массив:");
            int maxIndex1 = IndexOfMax1(array);
            Swap(array, 14, maxIndex1);
            OutputArray(listBox1, array, "\nМассив после замены последнего элемента с максимальным значением:");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var random = new Random();
            double[] array = new double[25];


            for (int i = 0; i < 25; i++)
            {
                
                bool isInteger = random.Next(2) == 0;

                if (isInteger)
                    array[i] += random.Next(-100, 101);

                else
                    array[i] += ((random.NextDouble() * 200) - 100);
            }
            OutputArray(listBox1, array, "Исходный массив:");
            int minIndex = IndexOfMin1(array);
            Swap(array, 0, minIndex);
            OutputArray(listBox1, array, "\nМассив после замены первого элемента с наименьшим значением:");

        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            var random = new Random();

            int[] array = Enumerable.Range(1, 30)
                                    .Select(_ => random.Next(-100, 100))
                                    .ToArray();
            OutputArray(listBox1, array, "Исходный массив:");

            listBox1.Items.Add("\nСумма отрицательных и нечетныъ элементов массива ="+nechetOtr(array));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            var random = new Random();

            int[] array = Enumerable.Range(1, 30)
                                    .Select(_ => random.Next(-100, 100))
                                    .ToArray();
            OutputArray(listBox1, array, "Исходный массив:");
            listBox1.Items.Add("\nСумма элементов массива кратных пяти =" + crat5(array));
        }
    }
}
